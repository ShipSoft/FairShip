enum ShipGlobals {
   kShipMuonsCrossSectionFactor   =  1
 };  

