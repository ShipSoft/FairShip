void DecayConfig() {
     // do nothing
}


