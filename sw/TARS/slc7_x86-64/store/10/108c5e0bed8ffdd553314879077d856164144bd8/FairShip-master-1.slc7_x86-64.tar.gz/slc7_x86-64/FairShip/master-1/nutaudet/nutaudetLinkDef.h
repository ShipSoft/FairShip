// $Id: nutaudetLinkDef.h,v 1.1.1.1 2005/06/23 07:14:26 dbertini Exp $

#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class NuTauMudet+;
#pragma link C++ class ShipRpcPoint+;
#pragma link C++ class Hpt+;
#pragma link C++ class HptPoint+;
#pragma link C++ class NutaudetContFact;
#pragma link C++ class EmulsionMagnet;
#pragma link C++ class TargetTracker+;
#pragma link C++ class TTPoint+;
#pragma link C++ class Target+;
#pragma link C++ class TargetPoint+;

#endif

