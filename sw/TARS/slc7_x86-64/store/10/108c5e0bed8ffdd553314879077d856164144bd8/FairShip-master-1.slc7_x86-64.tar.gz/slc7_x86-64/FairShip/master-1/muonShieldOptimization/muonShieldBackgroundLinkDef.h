// $Id: muonShieldBackgroundLinkDef.h,v 1  Thomas Ruf 13/6/2917 $

#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class  exitHadronAbsorber+;
#pragma link C++ class  pyFairModule+;
#pragma link C++ class  simpleTarget+;
#endif

