#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class strawtubesContFact;
#pragma link C++ class strawtubes+;
#pragma link C++ class strawtubesPoint+;
#pragma link C++ class strawtubesHit+;
#pragma link C++ class Tracklet+;

#endif
