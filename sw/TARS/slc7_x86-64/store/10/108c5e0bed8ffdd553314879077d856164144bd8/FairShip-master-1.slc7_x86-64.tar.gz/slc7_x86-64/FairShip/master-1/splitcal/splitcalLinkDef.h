#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class splitcalContFact;
#pragma link C++ class splitcal+;
#pragma link C++ class splitcalPoint+;
#pragma link C++ class splitcalHit+;
#pragma link C++ class splitcalCluster+;
#endif
