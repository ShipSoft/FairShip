#!/bin/bash -e
if [[ "$WORK_DIR" == '' ]]; then
  echo 'Please, define $WORK_DIR'
  exit 1
fi
OP=slc7_x86-64/FairShip/master-1
PP=${PKGPATH:-slc7_x86-64/FairShip/master-1}
PH=108c5e0bed8ffdd553314879077d856164144bd8
sed -e "s|/[^ ;:]*INSTALLROOT/$PH/$OP|$WORK_DIR/$PP|g;s|[@][@]PKGREVISION[@]$PH[@][@]|1|g" $PP/etc/profile.d/init.sh.unrelocated > $PP/etc/profile.d/init.sh
sed -e "s|/[^ ;:]*INSTALLROOT/$PH/$OP|$WORK_DIR/$PP|g;s|[@][@]PKGREVISION[@]$PH[@][@]|1|g" $PP/etc/modulefiles/FairShip.unrelocated > $PP/etc/modulefiles/FairShip
